"use client";

import { DemandSender } from "@/components/sender";

export default function DemandTextSenderPage() {
  return (
    <div className="flex flex-col md:my-4 flex-1 w-full">
      <DemandSender/>
    </div>
  );
}
