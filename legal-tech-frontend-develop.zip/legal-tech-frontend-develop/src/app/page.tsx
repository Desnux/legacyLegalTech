'use client';
import PrincipalMenu from "@/components/layout/principal-menu";

export default function Home() {

  return (
    <PrincipalMenu />
  );
}
