export { default as DemandTextAnalyzer } from "./demand-text";
