export { default as GoodsTable} from "./goods-table";
export type { GoodsGroup } from "./goods-table";
