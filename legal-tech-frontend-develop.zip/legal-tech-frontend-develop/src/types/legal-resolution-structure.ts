export interface LegalResolutionStructure {
  header: string | null;
  date_line: string | null;
  resolution: string | null;
  footer: string | null;
}