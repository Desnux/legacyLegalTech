export interface LawFirm {
    id: string;
    rut: string;
    name: string
    description: string | null;
}
