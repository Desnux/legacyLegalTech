export interface LegalResponseStructure {
  header: string | null;
  court: string | null;
  response: string | null;
  request: string | null;
}