from .lawfirm_service import create_law_firm, get_all_law_firms

__all__ = ["create_law_firm", "get_all_law_firms"]

