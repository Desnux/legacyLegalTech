from fastapi import APIRouter

router = APIRouter(prefix="/network", tags=["Network"])

from . import (
    email,
)
