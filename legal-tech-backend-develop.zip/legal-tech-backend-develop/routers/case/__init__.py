from fastapi import APIRouter

router = APIRouter(prefix="/case", tags=["Case"])

from . import (
    case,
)
