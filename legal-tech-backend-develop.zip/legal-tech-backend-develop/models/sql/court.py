from typing import TYPE_CHECKING

from sqlalchemy import Enum as ForeignKey
from sqlmodel import Field, SQLModel, Relationship
from uuid import UUID, uuid4


if TYPE_CHECKING:
    from .case import Case
    from .case_detail import CaseDetail
    from .tribunal import Tribunal


COURT_LABELS = {
    "Santiago": {i: f"{i}º Juzgado Civil de Santiago" for i in range(1, 31)},
    "Valparaiso": {i: f"{i}º Juzgado Civil de Valparaiso" for i in range(1, 6)},
    "Talca": {i: f"{i}º Juzgado de Letras de Talca" for i in range(1, 5)},
    "Copiapó": {i: f"{i}º Juzgado de Letras de Copiapó" for i in range(1, 5)},
    "Antofagasta": {i: f"{i}º Juzgado de Letras Civil de Antofagasta" for i in range(1, 5)},
    "San Miguel": {i: f"{i}º Juzgado Civil de San Miguel" for i in range(1, 5)},
    "Punta Arenas": {i: f"{i}º Juzgado de Letras de Punta Arenas" for i in range(1, 4)},
    "Ovalle": {i: f"{i}º Juzgado de Letras de Ovalle" for i in range(1, 4)},
    "Serena": {i: f"{i}º Juzgado de Letras de la Serena" for i in range(1, 4)},
    "Iquique": {i: f"{i}º Juzgado de Letras de Iquique" for i in range(1, 4)},
    "Coquimbo": {i: f"{i}º Juzgado de Letras de Coquimbo" for i in range(1, 4)},
    "Calama": {i: f"{i}º Juzgado de Letras de Calama" for i in range(1, 4)},
    "Arica": {i: f"{i}º Juzgado de Letras de Arica" for i in range(1, 4)},
    "Viña del Mar": {i: f"{i}º Juzgado Civil de Viña del Mar" for i in range(1, 4)},
    "Temuco": {i: f"{i}º Juzgado Civil de Temuco" for i in range(1, 4)},
    "Concepción": {i: f"{i}º Juzgado Civil de Concepción" for i in range(1, 4)},
    "Vallenar": {i: f"{i}º Juzgado de Letras de Vallenar" for i in range(1, 3)},
    "Talagante": {i: f"{i}º Juzgado de Letras de Talagante" for i in range(1, 3)},
    "San Fernando": {i: f"{i}º Juzgado de Letras de San Fernando" for i in range(1, 3)},
    "San Bernardo": {i: f"{i}º Juzgado de Letras de San Bernardo" for i in range(1, 3)},
    "San Antonio": {i: f"{i}º Juzgado de Letras de San Antonio" for i in range(1, 3)},
    "Quilpue": {i: f"{i}º Juzgado de Letras de Quilpue" for i in range(1, 3)},
    "Quillota": {i: f"{i}º Juzgado de Letras de Quillota" for i in range(1, 3)},
    "Osorno": {i: f"{i}º Juzgado de Letras de Osorno" for i in range(1, 3)},
    "Los Angeles": {i: f"{i}º Juzgado de Letras de Los Angeles" for i in range(1, 3)},
    "Los Andes": {i: f"{i}º Juzgado de Letras de Los Andes" for i in range(1, 3)},
    "Linares": {i: f"{i}º Juzgado de Letras de Linares" for i in range(1, 3)},
    "Curico": {i: f"{i}º Juzgado de Letras de Curico" for i in range(1, 3)},
    "Coronel": {i: f"{i}º Juzgado de Letras de Coronel" for i in range(1, 3)},
    "Buin": {i: f"{i}º Juzgado de Letras de Buin" for i in range(1, 3)},
    "Valdivia": {i: f"{i}º Juzgado Civil de Valdivia" for i in range(1, 3)},
    "Talcahuano": {i: f"{i}º Juzgado Civil de Talcahuano" for i in range(1, 3)},
    "Rancagua": {i: f"{i}º Juzgado Civil de Rancagua" for i in range(1, 3)},
    "Puerto Montt": {i: f"{i}º Juzgado Civil de Puerto Montt" for i in range(1, 3)},
    "Chillan": {i: f"{i}º Juzgado Civil de Chillan" for i in range(1, 3)},
    "Peumo": {None: "Jdo. de Letras y Garantia de Peumo"},
    "Santa Cruz": {i: f"{i}º Juzgado de Letras de Santa Cruz" for i in range(1, 2)},
    "San Felipe": {i: f"{i}º Juzgado de Letras de San Felipe" for i in range(1, 2)},
    "San Carlos": {i: f"{i}º Juzgado de Letras de San Carlos" for i in range(1, 2)},
    "Rengo": {i: f"{i}º Juzgado de Letras de Rengo" for i in range(1, 2)},
    "Melipilla": {i: f"{i}º Juzgado de Letras de Melipilla" for i in range(1, 2)},
    "Coyhaique": {i: f"{i}º Juzgado de Letras de Coyhaique" for i in range(1, 2)},
    "Puente Alto": {i: f"{i}º Juzgado Civil de Puente Alto" for i in range(1, 2)},
    "Puerto Varas": {i: f"{i}º Juzgado de Letras de Puerto Varas" for i in range(1, 2)},
    "Angol": {i: f"{i}º Juzgado De Letras de Angol" for i in range(1, 2)}, #De casing is correct
    "Putaendo": {None: "Juzgado de Letras y Gar.de Putaendo"},
    "Quintero": {None: "Juzgado de Letras y Gar.de Quintero"},
    "Petorca": {None: "Juzgado de Letras y Gar. de Petorca"},
    "Isla de Pascua": {None: "Juzgado de Letras y Gar. de Isla de Pascua"},
    "Ancud": {None: "Juzgado de Letras de Ancud"},
    "Arauco": {None: "Juzgado de Letras de Arauco"},
    "Cañete": {None: "Juzgado de Letras de Cañete"},
    "Casablanca": {None: "Juzgado de Letras de Casablanca"},
    "Castro": {None: "Juzgado de Letras de Castro"},
    "Cauquenes": {None: "Juzgado de Letras de Cauquenes"},
    "Colina": {None: "Juzgado de Letras de Colina"},
    "Constitución": {None: "Juzgado de Letras de Constitución"},
    "Diego de Almagro": {None: "Juzgado de Letras de Diego de Almagro"},
    "Illapel": {None: "Juzgado de Letras de Illapel"},
    "La Calera": {None: "Juzgado de Letras de La Calera"},
    "La Ligua": {None: "Juzgado de Letras de La Ligua"},
    "Lautaro": {None: "Juzgado de Letras de Lautaro"},
    "Limache": {None: "Juzgado de Letras de Limache"},
    "Mariquina": {None: "Juzgado de Letras de Mariquina"},
    "Molina": {None: "Juzgado de Letras de Molina"},
    "Nueva Imperial": {None: "Juzgado de Letras de Nueva Imperial"},
    "Parral": {None: "Juzgado de Letras de Parral"},
    "Peñaflor": {None: "Juzgado de Letras de Peñaflor"},
    "Pitrufquen": {None: "Juzgado de Letras de Pitrufquen"},
    "Rio Negro": {None: "Juzgado de Letras de Rio Negro"},
    "San Javier": {None: "Juzgado de Letras de San Javier"},
    "San Vicente de Tagua Tagua": {None: "Juzgado de Letras de San Vicente de Tagua Tagua"},
    "Tome": {None: "Juzgado de Letras de Tome"},
    "Victoria": {None: "Juzgado de Letras de Victoria"},
    "Vicuña": {None: "Juzgado de Letras de Vicuña"},
    "Villa Alemana": {None: "Juzgado de Letras de Villa Alemana"},
    "Villarrica": {None: "Juzgado de Letras de Villarrica"},
    "Yungay": {None: "Juzgado de Letras de Yungay"},
    "Loncoche": {None: "Juzgado de Letras de Loncoche"},
    "Los Lagos": {None: "Juzgado de Letras de Los Lagos"},
    "Tocopilla": {None: "Juzgado de Letras de Tocopilla"},
    "Lota": {None: "Juzgado de Letras y Garantía de Lota"},
    "Maullin": {None: "Juzgado de Letras y Garantía de Maullin"},
    "Mulchén": {None: "Juzgado de Letras y Garantía de Mulchén"},
    "Panguipulli": {None: "Juzgado de Letras y Garantía de Panguipulli"},
    "Puerto Natales": {None: "Juzgado de Letras y Garantía de Puerto Natales"},
    "Quellon": {None: "Juzgado de Letras y Garantía de Quellon"},
    "Taltal": {None: "Juzgado de Letras y Garantía de Taltal"},
    "Pozo Almonte": {None: "Juzgado de Letras y Garantía de Pozo Almonte"},
    "Santa Bárbara": {None: "Juzgado de Letras y Garantía de Santa Bárbara"},
    "Achao": {None: "Juzgado de Letras y Garantía de Achao"},
    "Andacollo": {None: "Juzgado de Letras y Garantía de Andacollo"},
    "Cabrero": {None: "Juzgado de Letras y Garantía de Cabrero"},
    "Calbuco": {None: "Juzgado de Letras y Garantía de Calbuco"},
    "Caldera": {None: "Juzgado de Letras y Garantía de Caldera"},
    "Carahue": {None: "Juzgado de Letras y Garantía de Carahue"},
    "Chile Chico": {None: "Juzgado de Letras y Garantía de Chile Chico"},
    "Cochrane": {None: "Juzgado de Letras y Garantía de Cochrane"},
    "Coelemu": {None: "Juzgado de Letras y Garantía de Coelemu"},
    "Collipulli": {None: "Juzgado de Letras y Garantía de Collipulli"},
    "Combarbalá": {None: "Juzgado de Letras y Garantía de Combarbalá"},
    "Curacautin": {None: "Juzgado de Letras y Garantía de Curacautin"},
    "Curanilahue": {None: "Juzgado de Letras y Garantía de Curanilahue"},
    "Florida": {None: "Juzgado de Letras y Garantía de Florida"},
    "Freirina": {None: "Juzgado de Letras y Garantía de Freirina"},
    "La Unión": {None: "Juzgado de Letras y Garantía de La Unión"},
    "Laja": {None: "Juzgado de Letras y Garantía de Laja"},
    "Lebu": {None: "Juzgado de Letras y Garantía de Lebu"},
    "Litueche": {None: "Juzgado de Letras y Garantía de Litueche"},
    "María Elena": {None: "Juzgado de Letras y Garantía de María Elena"},
    "Nacimiento": {None: "Juzgado de Letras y Garantía de Nacimiento"},
    "Paillaco": {None: "Juzgado de Letras y Garantía de Paillaco"},
    "Peralillo": {None: "Juzgado de Letras y Garantía de Peralillo"},
    "Porvenir": {None: "Juzgado de Letras y Garantía de Porvenir"},
    "Aisen": {None: "Juzgado de Letras y Garantía de Aisen"},
    "Pucon": {None: "Juzgado de Letras y Garantía de Pucon"},
    "Cisnes": {None: "Juzgado de Letras y Garantía de Cisnes"},
    "Purén": {None: "Juzgado de Letras y Garantía de Purén"},
    "Quirihue": {None: "Juzgado de Letras y Garantía de Quirihue"},
    "Rio Bueno": {None: "Juzgado de Letras y Garantía de Rio Bueno"},
    "Santa Juana": {None: "Juzgado de Letras y Garantía de Santa Juana"},
    "Cabo de Hornos ": {None: "Juzgado de Letras y Garantía de Cabo de Hornos "},
    "Bulnes": {None: "Juzgado de Letras y Garantía de Bulnes"},
    "Chaiten": {None: "Juzgado de Letras y Garantía de Chaiten"},
    "Chanco": {None: "Juzgado de Letras y Garantía de Chanco"},
    "Curepto": {None: "Juzgado de Letras y Garantía de Curepto"},
    "Hualaihue": {None: "Juzgado de Letras y Garantía de Hualaihue"},
    "Licantén": {None: "Juzgado de Letras y Garantía de Licantén"},
    "Los Muermos": {None: "Juzgado de Letras y Garantía de Los Muermos"},
    "Traiguen": {None: "Juzgado de Letras y Garantía de Traiguen"},
    "Yumbel": {None: "Juzgado de Letras y Garantía de Yumbel"},
    "Mejillones": {None: "Juzgado de Letras y Garantía Mejillones"},
    "Chañaral": {None: "Juzgado de Letras y Garantia de Chañaral"},
    "Los Vilos": {None: "Juzgado de Letras y Garantia de los Vilos"},
    "Pichilemu": {None: "Juzgado de Letras y Garantia de Pichilemu"},
    "Tolten": {None: "Juzgado de Letras y Garantia de Tolten"},
 }


class CourtCase(SQLModel, table=True):
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    city: str = Field(..., description="Court city")
    number: int | None = Field(None, description="Court number")
    role: str = Field(..., description="Case role")
    simulated: bool = Field(False, description="Whether it is a simulated court case or not")
    case_id: UUID = Field(
        ...,
        foreign_key="case.id",
        ondelete="CASCADE",
        nullable=False,
        description="Case ID",
    )
    case: "Case" = Relationship(
        back_populates="court_cases",
    )

    def get_court_label(self) -> str:
        city_courts: dict = COURT_LABELS.get(self.city, {})
        court_name = city_courts.get(self.number, city_courts.get(None, ""))
        return court_name


class Court(SQLModel, table=True):
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    recepthor_id: UUID = Field(..., description="External recepthor system ID for integration")
    name: str = Field(..., description="Court name")
    code: int = Field(..., description="Court code")
    case_details: list["CaseDetail"] = Relationship(back_populates="court")
    tribunals: list["Tribunal"] = Relationship(back_populates="court")
