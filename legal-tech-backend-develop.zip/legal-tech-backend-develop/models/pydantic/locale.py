from enum import Enum


class Locale(str, Enum):
    EN_US = "en_US"
    ES_ES = "es_ES"
